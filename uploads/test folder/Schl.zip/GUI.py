import os, time, tkinter, customtkinter
from PIL import Image
import mysql.connector as conn

customtkinter.set_appearance_mode("system")
customtkinter.set_default_color_theme("green")

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        # self.resizable(width=False, height=False) 
        self.title("Testing Python GUI")
        self.geometry("400x500")
        self.iconbitmap("favicon.ico")

        self.grid_columnconfigure(0, weight=2)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=2)
        self.grid_rowconfigure(0, weight=1)
        
        # creating BG gradient
        current_path = os.path.dirname(os.path.realpath(__file__))
        self.bg_image = customtkinter.CTkImage(Image.open(current_path + "/test_images/bg_gradient.jpg"),
                                               size=(1400,800))
        self.bg_image_label = customtkinter.CTkLabel(self, image=self.bg_image)
        self.bg_image_label.grid(row=0, column=0)
        
        # login page
        self.loginpage = customtkinter.CTkFrame(self, corner_radius=10, fg_color="#464646")
        self.loginpage.grid(row=0, column=0, padx= 0, pady= 0, sticky="ns")
        # self.label = customtkinter.CTkLabel(self.loginpage, image=self.bg_image,)
        # self.label.grid()
        self.login_label = customtkinter.CTkLabel(self.loginpage, text="CustomTkinter\nLogin Page",
                                                  font=customtkinter.CTkFont(size=35, weight="bold"))
        self.login_label.grid(row=1, column=0, padx=30, pady=(50, 15))
        self.username_entry = customtkinter.CTkEntry(self.loginpage, width=250, height=40, placeholder_text="username= root",corner_radius=30, font=customtkinter.CTkFont(size=20))
        self.username_entry.grid(row=2, column=0, padx=30, pady=(150, 15))
        self.pswrd_entry = customtkinter.CTkEntry(self.loginpage, width=250, height=40, placeholder_text="Password",corner_radius=30, font=customtkinter.CTkFont(size=20))
        self.pswrd_entry.grid(row=3, column=0, padx=30, pady=(10, 15))
        self.data_entry = customtkinter.CTkEntry(self.loginpage, width=250, height=40, placeholder_text="Database",corner_radius=30, font=customtkinter.CTkFont(size=20))
        self.data_entry.grid(row=4, column=0, padx=30, pady=(10, 15))
        self.btn = customtkinter.CTkButton(self.loginpage, text="Login", width=150, height=40, corner_radius=15, command=self.post)
        self.btn.grid(row=5, column=0)

        connect = conn.connect(
            host = "local host",
            user = "Hacktiv8or",
            passwd = self.pswrd_entry.get(),
            database = self.data_entry.get())
        if connect.is_connected() == False:
            print("Error connecting to the server")

        # main page
        self.main_frame1 = customtkinter.CTkFrame(self,corner_radius=10, fg_color="dark gray")
        self.main_frame2 = customtkinter.CTkFrame(self, corner_radius=10, width=750, fg_color="red")
        self.main_frame3 = customtkinter.CTkFrame(self, corner_radius=10, width=100, fg_color="blue")
        self.btn2 = customtkinter.CTkButton(self.main_frame1, text="Go Back", command=self.pre)
        self.btn2.grid(row=0,column=0)
        self.tabs = customtkinter.CTkTabview(self)
        self.tabs.grid(row=0, column=1, sticky="ewns")
        self.tab1 = self.tabs.add("Tab_1")
        self.tab1 = self.tabs.add("Tab_2")

    def post(self):
        print("Login Button Pressed! ")
        print(f"Username: '{self.username_entry.get()}'")
        print(f"Password: '{self.pswrd_entry.get()}'")
        print(f"Database Name: '{self.data_entry.get()}'")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=10)
        self.grid_columnconfigure(2, weight=1)
        self.bg_image_label.grid_forget()
        self.loginpage.grid_forget()
        self.main_frame1.grid(row=0, column=0, sticky="ewns")
        self.main_frame2.grid(row=0, column=1, sticky="ewns")
        self.main_frame3.grid(row=0, column=2, sticky="ewns")
    def pre(self):
        print("Going back to Login Page")
        self.main_frame1.grid_forget()
        self.main_frame2.grid_forget()
        self.main_frame3.grid_forget()
        self.loginpage.grid(row=0, column=0, padx= 0, pady= 0, sticky="ewns")
        self.bg_image_label.grid(row=0, column=0)
        # self.frame1 = customtkinter.CTkFrame(self, fg_color="blue")
        # self.frame1.grid(row=0, column=1, padx= 0, pady= 0, sticky="ewns")
        # self.frame2 = customtkinter.CTkFrame(self, fg_color="black")
        # self.frame2.grid(row=1, column=0, padx= 0, pady= 0, sticky="ewns")
        # self.frame4 = customtkinter.CTkFrame(self,fg_color="dark red")
        # self.frame4.grid(row=1, column=1, padx= 0, pady= 0, sticky="ewns")

        # chk1 = customtkinter.CTkCheckBox(self, text="Check_1", command="add_to_list(text)")
        # chk1.grid(row=0, column=1, padx=60, pady=0)
        
        
        self.mainloop()

if __name__ == "__main__":
    app = App()
    app.mainloop()