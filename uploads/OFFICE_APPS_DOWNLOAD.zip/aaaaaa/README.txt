put these 2 files in a folder named office 2021 or anything else....
Run "officedeploymenttool_17531-20046.exe"
	-> give the office2021 folder path in this .exe window
bring the folder to C drive
open CMD as ADMIN...
type this -->   "cd c:\Office 2021"
then this -->   "setup /configure configuration.xml"
and then wait until office downloads all files